#!/usr/bin/env bash
python3.6 hw2.py